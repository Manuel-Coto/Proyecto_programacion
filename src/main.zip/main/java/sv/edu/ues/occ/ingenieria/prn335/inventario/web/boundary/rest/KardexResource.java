package sv.edu.ues.occ.ingenieria.prn335.inventario.web.boundary.rest;

public class KardexResource {
}
