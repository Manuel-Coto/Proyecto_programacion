package sv.edu.ues.occ.ingenieria.prn335.inventario.web.boundary.servlet;

public enum ESTADO_CRUD {
    CREAR,
    MODIFICAR,
    NADA,
}
