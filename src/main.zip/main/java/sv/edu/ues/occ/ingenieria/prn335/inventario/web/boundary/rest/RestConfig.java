package sv.edu.ues.occ.ingenieria.prn335.inventario.web.boundary.rest;


import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/resources/v1")
public class RestConfig extends Application {
    // Additional code can be added here for configuration
}
