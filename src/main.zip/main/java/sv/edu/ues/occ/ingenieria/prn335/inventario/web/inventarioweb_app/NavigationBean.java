package sv.edu.ues.occ.ingenieria.prn335.inventario.web.inventarioweb_app;

public class NavigationBean {
}
