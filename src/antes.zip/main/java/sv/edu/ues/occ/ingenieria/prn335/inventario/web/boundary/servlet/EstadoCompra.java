package sv.edu.ues.occ.ingenieria.prn335.inventario.web.boundary.servlet;

public enum EstadoCompra {
    ORDEN,
    CREADA,
    APROBADA,
    RECHAZADA,
    ANULADA
}
